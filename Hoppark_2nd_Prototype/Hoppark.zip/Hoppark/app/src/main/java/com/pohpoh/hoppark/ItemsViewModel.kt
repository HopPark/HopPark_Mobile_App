package com.pohpoh.hoppark

class ItemsViewModel(val image: Int, val text: String) {
}